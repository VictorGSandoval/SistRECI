/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


public class MunicipalidadM {
    private Integer IDMUN;
    private String DIRMUN;
    private String NOMMUN;
    private String TLFMUN;
    private String ESTMUN;
//    private String CODUBI;

    public Integer getIDMUN() {
        return IDMUN;
    }

    public void setIDMUN(Integer IDMUN) {
        this.IDMUN = IDMUN;
    }

    public String getDIRMUN() {
        return DIRMUN;
    }

    public void setDIRMUN(String DIRMUN) {
        this.DIRMUN = DIRMUN;
    }

    public String getNOMMUN() {
        return NOMMUN;
    }

    public void setNOMMUN(String NOMMUN) {
        this.NOMMUN = NOMMUN;
    }

    public String getTLFMUN() {
        return TLFMUN;
    }

    public void setTLFMUN(String TLFMUN) {
        this.TLFMUN = TLFMUN;
    }

    public String getESTMUN() {
        return ESTMUN;
    }

    public void setESTMUN(String ESTMUN) {
        this.ESTMUN = ESTMUN;
    }
    
}
