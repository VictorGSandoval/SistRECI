/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Date;

/**
 *
 * @author govas
 */
public class PersonaM {
    private Integer IDPER;
    private String APEPATPER;
    private String APEMATERPER;
    private String NOMPER;
    private String FECNACPER;
    private String DNIPER;
    private String DIRPER;
    private String GENPER;
    private String CELPER;
    private String ESTPER;
//    private String CODUBI;
    private String ESTCIVPER;

    public Integer getIDPER() {
        return IDPER;
    }

    public void setIDPER(Integer IDPER) {
        this.IDPER = IDPER;
    }

    public String getAPEPATPER() {
        return APEPATPER;
    }

    public void setAPEPATPER(String APEPATPER) {
        this.APEPATPER = APEPATPER;
    }

    public String getAPEMATERPER() {
        return APEMATERPER;
    }

    public void setAPEMATERPER(String APEMATERPER) {
        this.APEMATERPER = APEMATERPER;
    }

    public String getNOMPER() {
        return NOMPER;
    }

    public void setNOMPER(String NOMPER) {
        this.NOMPER = NOMPER;
    }

    public String getFECNACPER() {
        return FECNACPER;
    }

    public void setFECNACPER(String FECNACPER) {
        this.FECNACPER = FECNACPER;
    }

    public String getDNIPER() {
        return DNIPER;
    }

    public void setDNIPER(String DNIPER) {
        this.DNIPER = DNIPER;
    }

    public String getDIRPER() {
        return DIRPER;
    }

    public void setDIRPER(String DIRPER) {
        this.DIRPER = DIRPER;
    }

    public String getGENPER() {
        return GENPER;
    }

    public void setGENPER(String GENPER) {
        this.GENPER = GENPER;
    }

    public String getCELPER() {
        return CELPER;
    }

    public void setCELPER(String CELPER) {
        this.CELPER = CELPER;
    }

    public String getESTPER() {
        return ESTPER;
    }

    public void setESTPER(String ESTPER) {
        this.ESTPER = ESTPER;
    }

    public String getESTCIVPER() {
        return ESTCIVPER;
    }

    public void setESTCIVPER(String ESTCIVPER) {
        this.ESTCIVPER = ESTCIVPER;
    }
    
    
}
