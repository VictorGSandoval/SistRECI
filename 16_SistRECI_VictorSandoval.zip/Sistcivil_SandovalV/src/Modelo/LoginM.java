/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;


public class LoginM {
    private Integer IDLOG;
    private String USRLOG;
    private String PSSWLOG;
    private String TIPLOG;
    private String ESTLOG;
//    private Integer IDPER;
//
//    public Integer getIDPER() {
//        return IDPER;
//    }
//
//    public void setIDPER(Integer IDPER) {
//        this.IDPER = IDPER;
//    }

    public Integer getIDLOG() {
        return IDLOG;
    }

    public void setIDLOG(Integer IDLOG) {
        this.IDLOG = IDLOG;
    }

    public String getUSRLOG() {
        return USRLOG;
    }

    public void setUSRLOG(String USRLOG) {
        this.USRLOG = USRLOG;
    }

    public String getPSSWLOG() {
        return PSSWLOG;
    }

    public void setPSSWLOG(String PSSWLOG) {
        this.PSSWLOG = PSSWLOG;
    }

    public String getTIPLOG() {
        return TIPLOG;
    }

    public void setTIPLOG(String TIPLOG) {
        this.TIPLOG = TIPLOG;
    }

    public String getESTLOG() {
        return ESTLOG;
    }

    public void setESTLOG(String ESTLOG) {
        this.ESTLOG = ESTLOG;
    }
}
